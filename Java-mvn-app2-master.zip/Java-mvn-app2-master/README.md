# mvn-hello-world-web-app
Java Hello World web application created using maven-archetype-webapp

#Test

## Dependancies
* git
* maven
* tomcat

